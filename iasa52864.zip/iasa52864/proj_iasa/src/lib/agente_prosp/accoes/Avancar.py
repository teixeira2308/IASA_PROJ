from lib.ecr.Accao import Accao
class Avancar(Accao):
    def __init__(self):
        pass